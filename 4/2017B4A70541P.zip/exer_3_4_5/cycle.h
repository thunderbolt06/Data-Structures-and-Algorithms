/*cycle.h*/
#include <linkedlist.h>

int testCyclic(struct linkedList* list);